import React, {useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';
export function App(){
 const [incidents,setIncidents]=useState([]),[selected,setSelected]=useState(null),[result,setResult]=useState(null),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const [form,setForm]=useState({title:'Kafka consumer lag',serviceName:'orders-service',severity:'HIGH',description:'Consumer lag increased after deployment; processing latency rising.'});
 async function refresh(){try{const r=await fetch('/api/incidents');if(!r.ok)throw Error('Unable to load incidents');setIncidents(await r.json())}catch(e){setError(e.message)}}
 useEffect(()=>{refresh()},[]);
 async function create(e){e.preventDefault();setError('');try{const r=await fetch('/api/incidents',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(form)});if(!r.ok)throw Error('Failed to create incident');await refresh()}catch(e){setError(e.message)}}
 async function updateStatus(id,status){setError('');try{const r=await fetch(`/api/incidents/${id}/status`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});if(!r.ok)throw Error('Unable to update incident status');await refresh()}catch(e){setError(e.message)}}
 async function investigate(id){setBusy(true);setSelected(id);setResult(null);setError('');try{const r=await fetch(`/api/incidents/${id}/investigate`,{method:'POST'});if(!r.ok)throw Error('Investigation service unavailable');setResult(await r.json());await refresh()}catch(e){setError(e.message)}finally{setBusy(false)}}
 return <main><header><div className="eyebrow">OPERATIONS / AI</div><h1>Incident Intelligence</h1><p>Investigate production incidents with evidence-backed AI assistance. Read-only by design.</p></header>
 <div className="layout"><section className="panel"><h2>Report incident</h2><form onSubmit={create}>
 <label>Title<input required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label>
 <label>Service<input required value={form.serviceName} onChange={e=>setForm({...form,serviceName:e.target.value})}/></label>
 <label>Severity<select value={form.severity} onChange={e=>setForm({...form,severity:e.target.value})}><option>LOW</option><option>MEDIUM</option><option>HIGH</option><option>CRITICAL</option></select></label>
 <label>Description<textarea required rows="4" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label>
 <button type="submit">Create incident</button></form></section>
 <section className="panel"><h2>Incident queue <span>{incidents.length}</span></h2>{incidents.length===0?<p>No incidents yet. Create one to begin.</p>:<div className="queue">{incidents.map(i=><article key={i.id} className={selected===i.id?'active':''}><div className="incident-head"><strong>#{i.id} · {i.title}</strong><em>{i.severity}</em></div><p>{i.serviceName} · {i.status}</p><div className="actions"><button disabled={busy} onClick={()=>investigate(i.id)}>{busy&&selected===i.id?'Investigating…':'Investigate'}</button><select aria-label={`Status for incident ${i.id}`} value={i.status} onChange={e=>updateStatus(i.id,e.target.value)}><option>OPEN</option><option>INVESTIGATING</option><option>MITIGATED</option><option>RESOLVED</option></select></div></article>)}</div>}</section></div>
 {error&&<div role="alert" className="error">{error}</div>}
 {result&&<section className="panel findings"><div className="eyebrow">INVESTIGATION #{result.incident_id} · {result.mode.toUpperCase()} MODE</div><h2>Assessment</h2><p>{result.analysis}</p><h3>Observed keywords</h3><ul>{(result.signals||[]).map((x,i)=><li key={i}>{x}</li>)}</ul><h3>Hypotheses (unverified)</h3><ul>{(result.hypotheses||[]).map((x,i)=><li key={i}>{x}</li>)}</ul><h3>Recommended next steps</h3><ol>{result.recommended_actions.map((x,i)=><li key={i}>{x}</li>)}</ol><h3>Retrieved runbooks</h3>{result.references.map((r,i)=><article key={i}><strong>{r.title}</strong><p>{r.content}</p></article>)}<p className="notice">No automated production changes were performed.</p></section>}
 </main>
}
createRoot(document.getElementById('root')).render(<App/>);
