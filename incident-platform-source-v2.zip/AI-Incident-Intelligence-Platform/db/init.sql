CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS knowledge (
 id BIGSERIAL PRIMARY KEY,
 title TEXT NOT NULL,
 content TEXT NOT NULL,
 embedding vector(384),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS knowledge_search_idx ON knowledge USING gin (to_tsvector('english', title || ' ' || content));
INSERT INTO knowledge(title,content)
SELECT 'Kafka consumer lag', 'Check consumer group lag, partition skew, downstream database latency, retries, and recent deployments. Scale consumers only up to the number of partitions.'
WHERE NOT EXISTS (SELECT 1 FROM knowledge WHERE title='Kafka consumer lag');
INSERT INTO knowledge(title,content)
SELECT 'Database connection exhaustion', 'Inspect connection pool metrics, long-running transactions, database max_connections, query timeouts and recent traffic changes.'
WHERE NOT EXISTS (SELECT 1 FROM knowledge WHERE title='Database connection exhaustion');
