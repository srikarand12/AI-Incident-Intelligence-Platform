from fastapi.testclient import TestClient
from main import app, reason, recommend

def test_health():
    assert TestClient(app).get('/health').json() == {'status': 'ok'}

def test_rule_fallback(monkeypatch):
    monkeypatch.delenv('OPENAI_API_KEY', raising=False)
    result = reason({'title':'Lag', 'description':'lag rising', 'service_name':'orders', 'references':[]})
    assert result['mode'] == 'rules'
    assert 'verification' in result['analysis']

def test_recommendations_require_approval():
    result = recommend({})
    assert any('approval' in a.lower() for a in result['recommended_actions'])

from main import triage, hypothesize

def test_triage_signals_are_derived_from_text():
    state={'title':'Kafka lag', 'description':'after deployment', 'service_name':'orders'}
    assert 'Consumer lag mentioned' in triage(state)['signals']
    assert 'Recent application or configuration change' in hypothesize(state)['hypotheses']

def test_no_unverified_root_cause_claim():
    state={'title':'Unknown', 'description':'Unexpected alert', 'service_name':'orders'}
    assert 'Cause undetermined' in hypothesize(state)['hypotheses'][0]
