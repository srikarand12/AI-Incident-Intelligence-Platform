package com.example.incident.model;
import jakarta.persistence.*;
import java.time.Instant;
@Entity
public class Investigation {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private Long incidentId;
 @Column(nullable=false,length=32) private String mode;
 @Column(nullable=false,length=20000) private String analysis;
 @Column(nullable=false,length=20000) private String evidenceJson;
 @Column(nullable=false,length=20000) private String actionsJson;
 private Instant createdAt=Instant.now();
 protected Investigation() {}
 public Investigation(Long incidentId,String mode,String analysis,String evidenceJson,String actionsJson){this.incidentId=incidentId;this.mode=mode;this.analysis=analysis;this.evidenceJson=evidenceJson;this.actionsJson=actionsJson;}
 public Long getId(){return id;} public Long getIncidentId(){return incidentId;} public String getMode(){return mode;} public String getAnalysis(){return analysis;} public String getEvidenceJson(){return evidenceJson;} public String getActionsJson(){return actionsJson;} public Instant getCreatedAt(){return createdAt;}
}
