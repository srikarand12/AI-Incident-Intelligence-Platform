package com.example.incident.api;
import com.example.incident.model.Incident;
import com.example.incident.model.Investigation;
import com.example.incident.repo.IncidentRepository;
import com.example.incident.repo.InvestigationRepository;
import com.example.incident.service.InvestigationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;
import java.util.Map;
import java.util.Set;
@RestController @RequestMapping("/api/incidents")
public class IncidentController {
 private static final Set<String> STATUSES=Set.of("OPEN","INVESTIGATING","MITIGATED","RESOLVED");
 private static final Set<String> SEVERITIES=Set.of("LOW","MEDIUM","HIGH","CRITICAL");
 private final IncidentRepository repo; private final InvestigationService investigation;
 private final InvestigationRepository history; private final ObjectMapper mapper;
 public IncidentController(IncidentRepository repo, InvestigationService investigation, InvestigationRepository history, ObjectMapper mapper){this.repo=repo;this.investigation=investigation;this.history=history;this.mapper=mapper;}
 @GetMapping public List<Incident> list(){return repo.findAll(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC,"createdAt"));}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Incident create(@Valid @RequestBody Incident incident){
  incident.setId(null);incident.setStatus("OPEN");incident.setCreatedAt(java.time.Instant.now());
  if(incident.getSeverity()==null || !SEVERITIES.contains(incident.getSeverity())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid severity");
  return repo.save(incident);
 }
 @GetMapping("/{id}") public Incident get(@PathVariable Long id){return repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Incident not found"));}
 @PatchMapping("/{id}/status") public Incident updateStatus(@PathVariable Long id,@RequestBody Map<String,String> request){
  String status=request.get("status");if(status==null || !STATUSES.contains(status))throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid status");
  Incident incident=get(id);incident.setStatus(status);return repo.save(incident);
 }
 @GetMapping("/{id}/investigations") public List<Investigation> history(@PathVariable Long id){get(id);return history.findByIncidentIdOrderByCreatedAtDesc(id);}
 @PostMapping("/{id}/investigate") public Map<String,Object> investigate(@PathVariable Long id){
  Incident incident=get(id);Map<String,Object> result=investigation.investigate(incident);
  try {
   history.save(new Investigation(id,String.valueOf(result.getOrDefault("mode","unknown")),String.valueOf(result.getOrDefault("analysis","")),mapper.writeValueAsString(result.getOrDefault("references",List.of())),mapper.writeValueAsString(result.getOrDefault("recommended_actions",List.of()))));
  } catch(JsonProcessingException ex){throw new IllegalStateException("Unable to serialize investigation",ex);}
  if(!"RESOLVED".equals(incident.getStatus())){incident.setStatus("INVESTIGATING");repo.save(incident);}
  return result;
 }
}
