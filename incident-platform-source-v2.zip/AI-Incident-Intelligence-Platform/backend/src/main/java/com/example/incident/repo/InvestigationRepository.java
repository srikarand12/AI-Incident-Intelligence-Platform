package com.example.incident.repo;
import com.example.incident.model.Investigation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface InvestigationRepository extends JpaRepository<Investigation,Long> {
 List<Investigation> findByIncidentIdOrderByCreatedAtDesc(Long incidentId);
}
