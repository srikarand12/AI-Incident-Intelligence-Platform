package com.example.incident.service;
import com.example.incident.model.Incident;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.Map;
@Service
public class InvestigationService {
 private final RestClient client;
 public InvestigationService(@Value("${agent.url}") String url){client=RestClient.builder().baseUrl(url).build();}
 @SuppressWarnings("unchecked") public Map<String,Object> investigate(Incident incident){
  return client.post().uri("/investigate").contentType(MediaType.APPLICATION_JSON)
   .body(Map.of("incident_id",incident.getId(),"title",incident.getTitle(),"description",incident.getDescription(),"service_name",incident.getServiceName()))
   .retrieve().body(Map.class);
 }
}
