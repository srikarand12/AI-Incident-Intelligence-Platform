package com.example.incident.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.Instant;
@Entity
public class Incident {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @NotBlank private String title;
 @NotBlank @Column(length=10000) private String description;
 @NotBlank private String serviceName;
 private String severity="MEDIUM";
 private String status="OPEN";
 private Instant createdAt=Instant.now();
 public Long getId(){return id;} public void setId(Long id){this.id=id;}
 public String getTitle(){return title;} public void setTitle(String v){title=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public String getServiceName(){return serviceName;} public void setServiceName(String v){serviceName=v;}
 public String getSeverity(){return severity;} public void setSeverity(String v){severity=v;}
 public String getStatus(){return status;} public void setStatus(String v){status=v;}
 public Instant getCreatedAt(){return createdAt;} public void setCreatedAt(Instant v){createdAt=v;}
}
