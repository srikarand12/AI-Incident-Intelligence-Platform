package com.example.incident.repo;
import com.example.incident.model.Incident;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IncidentRepository extends JpaRepository<Incident,Long> {}
