package com.example.incident;
import com.example.incident.api.IncidentController;
import com.example.incident.model.Incident;
import com.example.incident.repo.IncidentRepository;
import com.example.incident.repo.InvestigationRepository;
import com.example.incident.service.InvestigationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.util.Optional;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
class IncidentControllerTest {
 private final IncidentRepository repo=mock(IncidentRepository.class);
 private final InvestigationRepository history=mock(InvestigationRepository.class);
 private final InvestigationService agent=mock(InvestigationService.class);
 private final IncidentController controller=new IncidentController(repo,agent,history,new ObjectMapper());
 @Test void missingIncidentReturns404(){when(repo.findById(99L)).thenReturn(Optional.empty());ResponseStatusException error=assertThrows(ResponseStatusException.class,()->controller.get(99L));assertEquals(HttpStatus.NOT_FOUND,error.getStatusCode());}
 @Test void createResetsStatus(){when(repo.save(any(Incident.class))).thenAnswer(a->a.getArgument(0));Incident incident=new Incident();incident.setStatus("RESOLVED");assertEquals("OPEN",controller.create(incident).getStatus());}
 @Test void invalidStatusIsRejected(){when(repo.findById(1L)).thenReturn(Optional.of(new Incident()));assertThrows(ResponseStatusException.class,()->controller.updateStatus(1L,Map.of("status","UNKNOWN")));}
 @Test void investigationPersistsHistory(){Incident incident=new Incident();incident.setId(1L);incident.setTitle("Lag");incident.setDescription("Kafka lag");incident.setServiceName("orders");when(repo.findById(1L)).thenReturn(Optional.of(incident));when(agent.investigate(incident)).thenReturn(Map.of("mode","rules","analysis","Investigate","references",java.util.List.of(),"recommended_actions",java.util.List.of()));controller.investigate(1L);verify(history).save(any());assertEquals("INVESTIGATING",incident.getStatus());}
}
